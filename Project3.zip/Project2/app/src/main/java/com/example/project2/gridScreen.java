package com.example.project2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class gridScreen extends AppCompatActivity {

    private GridDBHelper gridDBHelper;
    private String[] items = new String[20];
    private ArrayAdapter<String> adapter;
    private GridView gridView;
    // Track the last clicked item
    private String lastClickedItem = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grid);

        gridDBHelper = new GridDBHelper(this);

        gridView = findViewById(R.id.grid1);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        gridView.setAdapter(adapter);

        Button addBtn = findViewById(R.id.addButton);
        Button editBtn = findViewById(R.id.editButton);
        Button delBtn = findViewById(R.id.deleteButton);


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newItemName = "New Item"; // You can replace this with user input
                gridDBHelper.insertGridItem(newItemName);

                // Update the items array
                loadItemsFromDatabase();

                // Notify the adapter to refresh the grid
                adapter.notifyDataSetChanged();
            }
        });

        delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Determine the selected item to delete (e.g., based on user's selection)
                String selectedItem = "New Item"; // Replace this with actual logic

                // Delete the item from the database
                gridDBHelper.deleteGridItem(selectedItem);

                // Update the items array
                loadItemsFromDatabase();

                // Notify the adapter to refresh the grid
                adapter.notifyDataSetChanged();
            }
        });

        for(int i = 0; i<items.length; i++){
            items[i] = "Item " +i;
        }


    }
    private void loadItemsFromDatabase() {
        SQLiteDatabase db = gridDBHelper.getReadableDatabase();
        String[] projection = {"item_name"};
        Cursor cursor = db.query("grid_items", projection, null, null, null, null, null);

        int index = 0;
        while (cursor.moveToNext()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            items[index++] = itemName;
        }

        cursor.close();
        db.close();
    }
}
