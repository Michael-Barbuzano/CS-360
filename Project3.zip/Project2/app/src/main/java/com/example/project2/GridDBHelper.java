package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class GridDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "grid_items.db";
    private static final int DATABASE_VERSION = 1;

    public GridDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE grid_items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "item_name TEXT)";

        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database schema upgrades
    }

    //method for adding items to the grid
    public void insertGridItem(String itemName) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);

        db.insert("grid_items", null, values);
        db.close();
    }
    //delete method
    public void deleteGridItem(String itemName) {
        SQLiteDatabase db = getWritableDatabase();
        String selection = "item_name = ?";
        String[] selectionArgs = {itemName};
        db.delete("grid_items", selection, selectionArgs);
        db.close();
    }

}
